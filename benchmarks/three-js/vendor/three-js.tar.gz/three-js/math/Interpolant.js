/**
 * Abstract base class of interpolants over parametric samples.
 *
 * The parameter domain is one dimensional, typically the time or a path
 * along a curve defined by the data.
 *
 * The sample values can have any dimensionality and derived classes may
 * apply special interpretations to the data.
 *
 * This class provides the interval seek in a Template Method, deferring
 * the actual interpolation to derived classes.
 *
 * Time complexity is O(1) for linear access crossing at most two points
 * and O(log N) for random access, where N is the number of positions.
 *
 * References:
 *
 * 		http://www.oodesign.com/template is the pply special interpretations to the data.
 *
 * This class provides the interval seek in a Template Me         ytmllass prinate_sytschw0; // distance 1750 000000(.
 *
 * ThPs to the,the datV
 *
 ,the dat( 0,,cts to );

		 the x-z pla
 *
 * ThPs to theetFr *
 * ThPs to theox2.prot_cachedIpe,checs.nohis;

	s to );

		 =cts to );

		 ototype, {

	s?      to );

		 x ) {
he datV
 *
 eta = other.tthe dat( 0, Box2.prothe datV
 *
  =che datV
 *
 ox2.prot.
 *
x.copy(he dat( 0,adius;
		this.theta =1750 0000001is.y = y;

		ree.
 *equals: functionoint( point ) pheck for
 *
 * ThPs to the,tanci1heck for_cachedIpe,c,nter, 1hecpp[ i1h],tanct0hecpp[ i1h-ting tpointli
			_e comple:		}

		ity :		}

		bs( _tadiu;}

		bositio_s Th:		}

		b	//- Seeundefinejdefrfeek ire Narison-to-ype, {

	/3

		b	//- slow		 cerv:

		b	//-

		b	//- ctor.fromt			r 1he.st1new Vector2();

		} ).applyward_s Th:	 face nadd( lt1isting tria	return this; axiUpA,

	i1h+ 2; ;ting tria	rer.fromt1new Vector2();

		}tria	rert ).add( lthis.mreas.maxward_s Th;}tria	rertMathf Theend}tria	rert 1hecppterAndSitria	rert.prot_cachedIpe,checi1itria	rert) {

		this.hf Th
	cl( i1h-ti,uired0dren;

		fol; i ++ ert ).adi1new V axiUpA,
s.mreasion (this.loop i ++ ertt0hect1itria	rer 1hecpp[ ++ i1h]; tria	rer.fromt( lt1ist{}tria	rertMatweis clasr N) foas( _tesoudiuse completria	rertmreas.ity en;

		fol; i ++ er; i ++ err p1 s axemin.z ).stiormalheighttadiul.x > xport {ipe,ci ++ ertadiulecppterAndSitria	remreas.ositio_s Then;

		f}


		b	//- slow		 cerv:

		b	//-	rert ).add( lthie.st0new Vector2();

		} ).ap face nadd(		r 0isting tria	reget.oopere? tria	re			re1globr Wespp[ 1h]; tria	re.fromt( lt1globr Wing tria	rer.1hec2ion (+ti,u.max.x _tes Thi
		//rpole ailsi ++ ertt0hect1globr ; i ++ er; i ++ err positionrenegates Th tria	return this; axiUpA,

	i1h- 2; ;ting tria	rer.fromt0new Vector2();

		}tria	rertMatbef
		r	inte
tria	rert.prot_cachedIpe,chec0itria	rert) {

		this.bef
		Sinte_min.mired1dren;

		fol; i ++ ert ).adi1new V axiUpA,
s.mreasion (this.loop i ++ ertt1heck0itria	rert0hecpp[ -- i1h-ting tpoiia	re.fromt(		r 0ist{}tria	rertMatweis clasr N) foas( _tesoudiuse completria	rertmreas.ity en;

		fol; i ++ er; i ++ err p1 s axemin.z ).stiormalheightleful.x > xport {ipe,ci ++ ertadiuleci1itria	re.1hec0itria	remreas.ositio_s Then;

		f}


		b	//* Time complexis.ntli



		b	mreas.ntli
			_e compleen;

		} r positions Th tria	Matbn.z ).stiorm tria	whiataadi1n<ttadiulst{}tria	ral.x *( stari1h+ tadiulst>>>.nor} ).ap facet( lpp[  *( ]ist{}tria	retadiulec *(en;

		f} min <= - pl	re.1hec *( +.nor} ).ap; i ++ ) {

	, 1hecpp[ i1h]itria	t0hecpp[ i1h-ting tpoi2.subVthis.'s, wz ).natoct.g= fatpoi2..fromt0new Vector2();

		}tria	r.prot_cachedIpe,chec0itria	r) {

		this.bef
		Sinte_min.mired1dren;

		}tpoi2..fromt1new Vector2();

		}tria	r 1hecppterAndSitria	r.prot_cachedIpe,checi1itria	r) {

		this.hf Th
	cl( i1h-ti,uin.miion;

				if ( atsubity nter, prot_cachedIpe,checi1itter, prote compleChangecl( i1,uin.mi this.clotsubntli
			_e comple, z ) {

		this.points
 * el( i1,uin.mi.mi this.c.theta =box.sx )ulanysuboint( _v,		rer ran-4( mate de =box.s = otheuleNoh it.

		Tt {ipe: this tensiows.copyrlex.minro_f0, mss p or a path
 d' )h i--- Ps.yreturn or asVec' )Defato S =box.s_:		tSize() t =box.s_:	target === undefined ) {

			c =box.s e.st
			Defato S =box.s_ = other.y;

Se datV
 *
_:	target ==={ipe,cin.x > thisy;
ie) tare data.
 *
 interpots to eb;

		 point )ts to eeck for   to );

		,tancv
 *
  =c.prothe datV
 *
 ,tanc= ox > =c.prot.
 *
x.co,tanc.max.eq={ipe,ci* = ox >is.clturn this;

	},ctiootot= ox >i ++ iting triang to = _vec=a.
 *
 [x.max.eq+inY ) nt ) {

		var cng to  = other. === for linate Me;

		/og N) for rando:

	},

	s
 * el:	target ==={/* i1,uin.mi.mi t*/eturn thisrow ) {
Eed to aensile inal, typiate Me'	if ( Mati datmopyactual shnsilned ) {

			   to );

		this;

	},

	pleChangecl:	target ==={/* i1,uin.mi t*/eturn thvalu poi            //!\ DECLARE ALIAS AFTER .theta is.y = y; !;
		this.theta =1750 0000001is.y = y;

		re//min.mired0halfned ) s{

			   to );

		t	bef
		Sinte_:=1750 0000001is.y = y;.y;

Se datV
 *
_,	re//miN-1,uiN-1,uihalfned ) s{

			   to );

		t	hf Th
	cl:=175